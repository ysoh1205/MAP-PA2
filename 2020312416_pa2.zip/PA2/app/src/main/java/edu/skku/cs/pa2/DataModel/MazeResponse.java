package edu.skku.cs.pa2.DataModel;

public class MazeResponse {
    private String maze;

    public String getMaze() {
        return maze;
    }

    public void setMaze(String maze) {
        this.maze = maze;
    }
}
