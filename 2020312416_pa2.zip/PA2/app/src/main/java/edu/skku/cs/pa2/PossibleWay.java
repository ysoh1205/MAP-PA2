package edu.skku.cs.pa2;

public class PossibleWay {
    boolean UP;
    boolean DOWN;
    boolean LEFT;
    boolean RIGHT;

    @Override
    public String toString() {
        return "PossibleWay{" +
                "UP=" + UP +
                ", DOWN=" + DOWN +
                ", LEFT=" + LEFT +
                ", RIGHT=" + RIGHT +
                '}';
    }
}
