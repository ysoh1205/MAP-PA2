package edu.skku.cs.pa2.DataModel;

public class UsersPostResponse {
    private String success;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }
}
